﻿Public Class frmpago
    Private Sub Label7_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub GroupBox4_Enter(sender As Object, e As EventArgs)

    End Sub
End Class