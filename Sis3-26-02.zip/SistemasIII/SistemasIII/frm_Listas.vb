﻿Public Class frm_Listas
    Private Sub grb_Filtro_Enter(sender As Object, e As EventArgs) Handles grb_Filtro.Enter

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class